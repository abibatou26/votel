<?php include ('head.php');?>

<body>
	<?php include ('view_banner.php');?>

    <heading class="voters_heading">
        
    </heading>
   
    <div class="image">
    	<img src="./hand-putting-voting-paper-ballot-box-online-concept-vector-illustration-flat-style-152800360.jpg" margin-left="100px" width="80%" height="600px"/>
    </div>
    <div class="union-infor">
    	
    </div>


    <?php    
        include ('footer.php');
        ?>

   </body>
</html>

