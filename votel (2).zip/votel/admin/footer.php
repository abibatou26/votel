

<!DOCTYPE html>
<html>
  <head>
    <title>Titre du document</title>
    <style>
      
      footer {
        
        background: #666;
        color: white;
		bottom: 0px;
		left: 0px;
		position: absolute;
		width: 100%;
		height:10%;
      }
    
    </style>
  </head>
  <body>
    
    <footer>
      <p>Online Voting System</p>
    </footer>
  </body>
</html>